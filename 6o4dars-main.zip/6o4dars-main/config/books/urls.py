from django.urls import path
from . import views

urlpatterns = [
    path('', views.author_list, name='author_list'),
    path('book/', views.book_list, name='book_list'),
    path('review/', views.review_list, name='review_list'),
]